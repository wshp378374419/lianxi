import React, { Component } from "react";

import IndexRouter from "./router/IndexRouter";
import "antd/dist/antd.css";
import "./app.css";
export default class App extends Component {
  render() {
    return (
      <div>
        <IndexRouter></IndexRouter>
      </div>
    );
  }
}
