import axios from "axios";
let fetchData = axios.create({
  baseUrl: "http://127.0.0.1:8088", //路径
});

// fetchData
export async function login({ username, passsword }) {
  return await fetchData.get("/users", { params: { username, password } });
}
