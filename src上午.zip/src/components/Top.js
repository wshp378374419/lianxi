import React from "react";

function Top(props) {
  return (
    <div className="top">
      <div
        className="left"
        onClick={() => {
          props.history.push("/");
        }}
      >
        logo
      </div>
      <ul className="right">
        <li>你好,张三</li>
        <li onClick={() => props.history.replace("/login")}>登录</li>
        <li>退出</li>
        <li>注册</li>
      </ul>
    </div>
  );
}

export default Top;
