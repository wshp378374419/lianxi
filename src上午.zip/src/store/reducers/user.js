export default function user(state = { username: "zhangsan" }, action) {
  return state;
}
