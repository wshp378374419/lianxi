import React, { Component } from "react";

class Classes extends Component {
  render() {
    return <div>Classes</div>;
  }
}

export default Classes;
