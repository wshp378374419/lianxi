import React, { Component } from "react";

class Company extends Component {
  render() {
    return <div>Company</div>;
  }
}

export default Company;
