import React, { Component } from "react";

class School extends Component {
  render() {
    return <div>scholl</div>;
  }
}

export default School;
