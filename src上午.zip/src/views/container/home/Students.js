import React, { Component } from "react";

class Students extends Component {
  render() {
    return <div>students</div>;
  }
}

export default Students;
