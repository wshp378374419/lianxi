import React, { Component } from "react";

class Worker extends Component {
  render() {
    return <div>Worker</div>;
  }
}

export default Worker;
