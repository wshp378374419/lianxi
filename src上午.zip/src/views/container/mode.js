import { connect } from "react-redux";

function mapStateToProps(state, ownProps) {
  return {};
}

function mapDispatchToProps(dispatch, ownProps) {
  return {};
}
export default connect(mapStateToProps, mapDispatchToProps)(Home);
